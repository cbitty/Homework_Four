using UnityEngine;

public class RocketController : MonoBehaviour
{
    public float thrust = 5f; // Speed for upward movement
    public float rotationSpeed = 100f; // Speed for rotation
    private Rigidbody rb; // Reference to the Rigidbody component
    private AudioSource audioSource; // Reference to the AudioSource component

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>(); // Get the Rigidbody attached to the rocket
        audioSource = GetComponent<AudioSource>(); // Get the AudioSource attached to the rocket
    }

    // Update is called once per frame
    void Update()
    {
        // Move the rocket upward when the "W" key is pressed
        if (Input.GetKey(KeyCode.W))
        {
            rb.AddForce(Vector3.up * thrust);

            // Play the audio if it is not already playing
            if (!audioSource.isPlaying)
            {
                audioSource.Play();
            }
        }
        else
        {
            // Stop the audio when the "W" key is not pressed
            audioSource.Stop();
        }

        // Rotate the rocket left when the "J" key is pressed
        if (Input.GetKey(KeyCode.J))
        {
            transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
        }

        // Rotate the rocket right when the "L" key is pressed
        if (Input.GetKey(KeyCode.L))
        {
            transform.Rotate(-Vector3.forward * rotationSpeed * Time.deltaTime);
        }
    }
}
